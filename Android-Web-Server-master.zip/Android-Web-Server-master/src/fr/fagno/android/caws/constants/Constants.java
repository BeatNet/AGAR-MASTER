package fr.fagno.android.caws.constants;

public class Constants {
	public static final String CAWS_MESSAGE = "cawsmessage";
	public static final String PREF_SERVER_PORT = "prefServerPort";
	public static final int DEFAULT_SERVER_PORT = 8080;
	public static final Boolean LOG_DEBUG = false;
}
